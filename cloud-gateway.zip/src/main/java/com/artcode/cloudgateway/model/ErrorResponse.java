/**
 * 
 */
package com.artcode.cloudgateway.model;

/**
 * @author VISION
 *
 */
public class ErrorResponse {

	private String requestApiName;

	private String msg;

	public String getRequestApiName() {
		return requestApiName;
	}

	public void setRequestApiName(String requestApiName) {
		this.requestApiName = requestApiName;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	
}
